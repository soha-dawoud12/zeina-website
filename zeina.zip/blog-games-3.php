<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>كتالوج الألعاب</title>
    <?php include 'blocks/layouts/head-resources.php' ?>
</head>

<body class="header-fixed">
<?php include 'social.php' ?>

<div class="loader">
    <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>

</div>
            <?php include 'blocks/layouts/header.php'?>
            <?php include 'blocks/pages/mobile-menu.php'?>

   <div id="blog" class="block catalog-games h-100 mt-xl-4 wow bounceInDown " data-wow-duration="2s" data-wow-delay="50ms">
    <div class="container">


        <div class=" col-12 pt-4 m-auto ">

            <img src="uploads/بروشور-1.jpg"  class="img-fluid" alt="">


        </div>
    </div>

</div>

            <?php include 'blocks/layouts/footer.php'?>

            <?php include 'blocks/layouts/foot-resources.php' ?>
</body>
</html>