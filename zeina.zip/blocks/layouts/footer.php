<footer >
    <div class="container ">
        <div class="main-footer pt-md-4">


           <div class="row pt-5">
                    <div class=" col-12 col-md-4 ">

                        <h4>عن زينة</h4>
                        <p>جمعية مستقلة مؤلفة من أشخاص اتحدوا معا طواعية لتحقيق احتياجاتهم وتطلعتهم الاقتصادية والاجتماعية والثقافية المشتركة عن طريق منشأة مملوكة ملكية جماعية ويشرف عليها ديمقراطيا.</p>
                    </div>



                    <div class="  col col-md mb-3">
                        <h4>روابط مهمة</h4>
                        <div class=" socials pt-1">
                            <ul class="list-unstyled">
                                <li class="mb-md-2"> <a href="#"> عن زينة</a></li>
                                <li class="mb-md-2"> <a href="#">فريق العمل</a></li>
                                <li class="mb-md-2"> <a href="#"> قصص نجاح</a></li>
                                <li class="mb-md-2"> <a href="#">مبادئ العمل التعاوني</a></li>
                                <li class="mb-md-2"> <a href="#">مجموعات المناصرة</a></li>

                            </ul>


                        </div>
                    </div>
                   <div class=" col-7 col-md-3 ">
                       <h4>اتصل بنا</h4>
                       <ul class="list-unstyled">
                           <li class="mb-md-2">0594560026, 0598866590</li>
                           <li class="mb-md-2">  <a href="tel:0594606264" > 0594606264</a>   </li>
                           <li class="mb-md-2">  <a href="tel:0594606264" >   082494121</a>   </li>
                           <li class="mb-md-2">     0594560026,0598866590</li>
                           <li class="mb-md-2"><a href="mailto:info@zeinacooperative.org"   >  info@zeinacooperative.org</a></li>


                       </ul>
                   </div>

                    <div class=" emalis  col col-md-3 mb-3">
                        <h4>النشرة البريدية</h4>
                        <input type="email" class="form-control mb-2 bg-secondary border-primary " placeholder="البريد الالكتروني " aria-label="email" aria-describedby="basic-addon1" >
                        <a href="#">
                            <button  type="submit"  class="  mt-3 mt-md-0  mb-1 mb-md-0">
                                اشترك
                            </button></a>
                    </div>





                    </div>

                </div>


            </div>
            <div class="copy  p-2 p-md-4 bg-success text-white">
                <div class="container">


                <div class="row d-flex justify-content-between m-0 p-0">
                    <div>جميع الحقوق محفوظة
                        &copy;  <span id="year"></span>


                    </div>
                    <div>تم تمويل الموقع من CFD</div>
                </div>
                </div>
            </div>
        </footer>

        <a href="" class="scroll-to-top shadow-sm">
            <i class="fas fa-arrow-up text-white"></i>
        </a>