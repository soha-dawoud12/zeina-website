<div class="mobile-menu">

            <div class="col-auto">
                    <ul class="list-unstyled  my-auto ">

                        <li class="active">
                            <a href="../../index.php"  >الرئيسية</a>
                        </li>

                        <li class="">
                            <a href="../../store-1.php"  >المتجر</a>
                        </li>
                        <li class="has-menu">
                            <a href="" >
                                عن زينة <i class="fas fa-angle-down text-primary ml-2 mr-2"> </i>
                            </a>

                            <div class="menu-box shadow-sm">
                                <a href="./why-zeina-association.php" class="d-block font-weight-bold " style="color: var(--primary) !important;">الجمعية التعاونية</a>
                                <a href="./why-zeina-2-principles.php" class="d-block">مبادئ العمل التعاوني</a>
                                <a href="./why-zeina-3-group.php" class="d-block">مجموعات المناصرة</a>

                                <a href="./why-zeina-4-teams.php" class="d-block">فريق العمل</a>
                                <a href="./why-zeina-5-policy.php" class="d-block">سياسة التمويل</a>
                                <a href="./why-zeina-6-background.php" class="d-block">خلفية معرفية</a>

                                <a href="./why-zeina-7-our-partners.php" class="d-block">شركاؤنا</a>
                                <a href="./why-zeina-8-our-commitment.php" class="d-block">التزامنا بالمسائلة</a>

                                <a href="./why-zeina-9-documents.php" class="d-block">الوثائق الأساسية</a>

                                <a href="#" class="d-block close-menu border-0" ><i class="fas fa-arrow-up text-primary"></i></a>
                            </div>
                        </li>
                        <li class="has-menu">
                            <a > المدونة <i class="fas fa-angle-down text-primary ml-2 mr-2"> </i> </a>

                            <div class="menu-box shadow-sm">

                                <a href="./blog-news-1.php" class="d-block font-weight-bold " style="color: var(--primary) !important;">الأخبار</a>

                                <h6  class="d-block font-weight-bold mt-2" >   المعرض  </h6>

                                <a href="./blog-Brochure-2.php" class="" style="color: var(--primary) !important;">بروشور </a>
                                <a href="./blog-games-3.php" class="">كتالوج الألعاب </a>
                                <div class="line  w-25 position-absolute" ></div>
                                <h6 class="d-block mt-2 font-weight-bold" > مدونات السلوك</h6>
                                <a href="./blog-corruption-Blog-4.php" class="">مدونة الفساد </a>
                                <a href="./blog-complaints-Blog-5.php" class="">مداونة الشكاوي </a>

                                <div class=" line w-25 position-absolute" ></div>


                                <a href="./blog-Ads-6.php" class="d-block">اعلانات</a>
                                <a href="./blog-story-7.php" class="d-block">قصص النجاح</a>

                                <a href="#" class="d-block close-menu border-0" ><i class="fas fa-arrow-up text-primary"></i></a>
                            </div>
                        </li>






                        <li class="">
                            <a href="../../contact-us.php" >اتصل بنا</a>
                        </li>



                        <li class=" text-center">

                            <a href="#" style="border-bottom: 0 !important;"> <button class=" btn-outline  mb-1 mb-md-0" >تسجيل دخول / جديد</button></a>

                        </li>


                    </ul>

            </div>



</div>