<div id="projects" class="block  projects wow fadeInDown " data-wow-duration="1.2s" data-wow-delay="50ms">
<!--    <div>-->
        <div class="container">
            <div class="head-start text-center mb-5">
                <h2 class="line-home">المشاريع</h2>
            </div>


  <div class=" swiper-container  " style="border-radius: 35px;padding-bottom: 27px; ">
                    <div class="overlay" ></div>
                        <div class="swiper-wrapper ">

                            <div class="swiper-slide  text-center col-12 col-md-6   col-lg-3   pt-4  active">
                                <div class="image-box">
                                    <a href="#" class="d-block img-box-img">
                                        <img src="assets/images/project.webp" class="img-fluid w-100" alt="مشروع.jpg">
                                    </a>
                                </div>
                                <article class="entry-body    bg-secondary  h-100"  style="width: 180px ;margin-top: -45px">


                                    <div class="entry-text  pt-4 pb-2 pr-2 pl-2 " >
                                        <div class="mt-3 mb-3">
                                            <a href=""><h3>عنوان البرنامج </h3></a>
                                        </div>
                                        <div>
                                            <p class="entry-title mb-2 ">
                                                نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                            </p>
                                        </div>
                                        <div class="d-flex  justify-content-center ">
                                            <span class="font-weight-bold  px-2" > <del>70$ </del></span>
                                            <span class="font-weight-bold text-success px-2"> 50$ </span>
                                        </div>

                                    </div>
                                    <div class="  my-auto  more add  d-flex justify-content-center ">
                                        <a href="">   <button class=" btn-outline  bg-primary mb-1 mb-md-0" >إضافة الي السلة</button></a>
                                    </div>

                                </article>

                            </div>
                            <div class="swiper-slide  text-center col-12 col-md-6   col-lg-3   pt-4  active">
                                    <div class="image-box">
                                        <a href="#" class="d-block img-box-img">
                                            <img src="assets/images/project.webp" class="img-fluid w-100" alt="مشروع.jpg">
                                        </a>
                                    </div>
                                    <article class="entry-body    bg-secondary  h-100"  style="width: 180px ;margin-top: -45px">


                                        <div class="entry-text  pt-4 pb-2 pr-2 pl-2 " >
                                                <div class="mt-3 mb-3">
                                                    <a href=""><h3>عنوان البرنامج </h3></a>
                                                </div>
                                                <div>
                                                    <p class="entry-title mb-2 ">
                                                        نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                                    </p>
                                                </div>
                                                <div class="d-flex  justify-content-center ">
                                                <span class="font-weight-bold  px-2" > <del>70$ </del></span>
                                                <span class="font-weight-bold text-success px-2"> 50$ </span>
                                            </div>

                                        </div>
                                        <div class="  my-auto  more add  d-flex justify-content-center ">
                                            <a href="">   <button class=" btn-outline  bg-primary mb-1 mb-md-0" >إضافة الي السلة</button></a>
                                        </div>

                                </article>

                            </div>
                            <div class="swiper-slide   text-center col-12 col-md-6   col-lg-3   pt-4  ">
                                <div class="image-box">
                                    <a href="#" class="d-block img-box-img">
                                        <img src="assets/images/project.webp" class="img-fluid w-100" alt="مشروع.jpg">
                                    </a>
                                </div>
                                <article class="entry-body    bg-secondary  h-100"  style="width: 180px ;margin-top: -45px">


                                    <div class="entry-text  pt-4 pb-2 pr-2 pl-2 " >
                                        <div class="mt-3 mb-3">
                                            <a href=""><h3>عنوان البرنامج </h3></a>
                                        </div>
                                        <div>
                                            <p class="entry-title mb-2 ">
                                                نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                            </p>
                                        </div>
                                        <div class="d-flex  justify-content-center ">
                                            <span class="font-weight-bold  px-2" > <del>70$ </del></span>
                                            <span class="font-weight-bold text-success px-2"> 50$ </span>
                                        </div>

                                    </div>
                                    <div class="  my-auto  more add  d-flex justify-content-center ">
                                        <a href="">   <button class=" btn-outline  bg-primary mb-1 mb-md-0" >إضافة الي السلة</button></a>
                                    </div>

                                </article>

                            </div>
                            <div class="swiper-slide text-center col-auto col-md-6   col-lg-3    pt-4  ">
                                <div class="image-box">
                                    <a href="#" class="d-block img-box-img">
                                        <img src="assets/images/project.webp" class="img-fluid w-100" alt="مشروع.jpg">
                                    </a>
                                </div>
                                <article class="entry-body    bg-secondary  h-100"  style="width: 180px ;margin-top: -45px">


                                    <div class="entry-text  pt-4 pb-2 pr-2 pl-2 " >
                                        <div class="mt-3 mb-3">
                                            <a href=""><h3>عنوان البرنامج </h3></a>
                                        </div>
                                        <div>
                                            <p class="entry-title mb-2 ">
                                                نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                            </p>
                                        </div>
                                        <div class="d-flex  justify-content-center ">
                                            <span class="font-weight-bold  px-2" > <del>70$ </del></span>
                                            <span class="font-weight-bold text-success px-2"> 50$ </span>
                                        </div>

                                    </div>
                                    <div class="  my-auto  more add  d-flex justify-content-center ">
                                        <a href="">   <button class=" btn-outline  bg-primary mb-1 mb-md-0" >إضافة الي السلة</button></a>
                                    </div>

                                </article>

                            </div>
                            <div class="swiper-slide text-center col-auto col-md-6   col-lg-3   pt-4  ">
                                <div class="image-box">
                                    <a href="#" class="d-block img-box-img">
                                        <img src="assets/images/project.webp" class="img-fluid w-100" alt="مشروع.jpg">
                                    </a>
                                </div>
                                <article class="entry-body    bg-secondary  h-100"  style="width: 180px ;margin-top: -45px">


                                    <div class="entry-text  pt-4 pb-2 pr-2 pl-2 " >
                                        <div class="mt-3 mb-3">
                                            <a href=""><h3>عنوان البرنامج </h3></a>
                                        </div>
                                        <div>
                                            <p class="entry-title mb-2 ">
                                                نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                            </p>
                                        </div>
                                        <div class="d-flex  justify-content-center ">
                                            <span class="font-weight-bold  px-2" > <del>70$ </del></span>
                                            <span class="font-weight-bold text-success px-2"> 50$ </span>
                                        </div>

                                    </div>
                                    <div class="  my-auto  more add  d-flex justify-content-center ">
                                        <a href="">   <button class=" btn-outline  bg-primary mb-1 mb-md-0" >إضافة الي السلة</button></a>
                                    </div>

                                </article>

                            </div>

                        </div>
                    </div>
        </div>

<!--                     Add Pagination-->
                    <div class="swiper-button-next"><i class="fas fa-arrow-left"></i></div>

                </div>
    </div>







