<div id="contact" class="block  mt-md-3 wow bounceInUp  contact ">
    <div class="container ">

        <div class="head-start text-center">
            <h2 class=" bg-white w-50 m-auto  line-home">اتصل بنا </h2>

        </div>


        <form class="container p-lg-4 mt-4 mt-lg-0 bg-white   " action="/index/message/submit" method="post" id="contact">

            <div class="row">
                <div class="col-lg-12  ">
                    <input type="text" class="form-control form-control-lg border-success " id="cont_name" placeholder="الاسم بالكامل" name="name" style="font-size: 90%;border-width: 1px " required="">

                    <input type="email" class="form-control form-control-lg mt-2  border-success" id="cont_email" placeholder="الإيميل" name="email" style="font-size: 90%;border-width: 1px" required="">

                </div>


                <div class="col-lg-12 ">
                    <div class="form-group">

                        <textarea class="form-control form-control-lg  mt-2  border-success" id="mass" placeholder="نص الرسالة" rows="3" name="message" style="font-size: 94%;border-width: 1px" required=""></textarea>
                    </div>
                    <div class="input-btn">
                        <input type="submit" class="btn col-12  btn-outline-primary "  value="Send" name="submit">
                    </div>

                </div>

            </div>


        </form>







        </div>

    </div>
