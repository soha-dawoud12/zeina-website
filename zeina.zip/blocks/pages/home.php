            <div id="home" class="block  home h-100 mt-xl-4  wow fadeInDownBig" data-wow-duration=".5s" data-wow-delay="50ms">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="container">


                                <div class="row d-flex align-items-center">


                                    <div class="col-12 col-md-6 home-text ">
                                        <h1 >جمعية زينة </h1>
                                        <h2 class="text-primary">التعاونية للمشغولات اليدوية </h2>
                                        <p class="pd-home">نص افتراضي نص افتراضي نص افتراضي نص افتراضينص افتراضي نص افتراضي نص افتراضي نص افتراضي

                                            نص افتراضي نص افتراضي نص افتراضي نص افتراضينص افتراضي نص افتراضي نص افتراضي نص افتراضي
                                        </p>
                                        <a href="#">  <button class=" btn-outline mt-3 mt-md-0  mb-1 mb-md-0" >  تواصل معنا <i class="fas fa-arrow-left mr-4"></i></button></a>
                                    </div>
                                    <div class="home-img  col-12 col-md-6 mb-3 ">
                                        <img src="./assets/images/slide2.png" alt="zeina-home-img"  title="zeina" class="img-fluid ">
                                    </div>




                                </div>



                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="container">



                                <div class="row d-flex align-items-center">


                                    <div class="col-12 col-md-6 home-text ">
                                        <h1 >جمعية زينة </h1>
                                        <h2 class="text-primary">التعاونية للمشغولات اليدوية </h2>
                                        <p class="pd-home">نص افتراضي نص افتراضي نص افتراضي نص افتراضينص افتراضي نص افتراضي نص افتراضي نص افتراضي

                                            نص افتراضي نص افتراضي نص افتراضي نص افتراضينص افتراضي نص افتراضي نص افتراضي نص افتراضي
                                        </p>
                                        <a href="#">  <button class=" btn-outline mt-3 mt-md-0  mb-1 mb-md-0" >  تواصل معنا <i class="fas fa-arrow-left mr-4"></i></button></a>
                                    </div>
                                    <div class="home-img  col-12 col-md-6 mb-3 ">
                                        <img src="./assets/images/slide1.png" alt="zeina-home-img"  title="zeina" class="img-fluid ">
                                    </div>




                                </div>



                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="container">



                                <div class="row d-flex align-items-center">


                                    <div class="col-12 col-md-6 home-text ">
                                        <h1 >جمعية زينة </h1>
                                        <h2 class="text-primary">التعاونية للمشغولات اليدوية </h2>
                                        <p class="pd-home">نص افتراضي نص افتراضي نص افتراضي نص افتراضينص افتراضي نص افتراضي نص افتراضي نص افتراضي

                                            نص افتراضي نص افتراضي نص افتراضي نص افتراضينص افتراضي نص افتراضي نص افتراضي نص افتراضي
                                        </p>
                                        <a href="#">  <button class=" btn-outline mt-3 mt-md-0  mb-1 mb-md-0" >  تواصل معنا <i class="fas fa-arrow-left mr-4"></i></button></a>
                                    </div>
                                    <div class="home-img  col-12 col-md-6 mb-3 ">
                                        <img src="./assets/images/slide3.png" alt="zeina-home-img"  title="zeina" class="img-fluid ">
                                    </div>




                                </div>



                            </div>
                        </div>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination d-flex justify-content-center  swiper-pagination-clickable"></div>
                </div>




            </div>

