<div id="lastnews" class="block btn-special lastnews" >
    <div class="container">


        <div class="head-start  text-center mb-5">
            <h2 class="line-home"> اخر الأخبار</h2>

        </div>
        <div class="swiper-container  ">
            <div class="swiper-wrapper  ">

                <div class="swiper-slide col-12  col-md-6  col-lg-4 p-4 h-100">
                    <div class="col-auto col-md-12 p-0 pb-2">

                        <article class="entry-box-1 mb-4 bg-primary shadow-sm h-100" >
                            <div class="new-box">
                                <div class="new  bg-primary text-white py-4  ">
                                    جديد
                                </div>
                                <a href="#" class="d-block">
                                    <img src="uploads/Ad1.jpg" class="img-fluid w-100" alt="اعلان.jpg">
                                </a>
                            </div>

                            <div class="entry-body p-3 pb-1">

                                <div class="row d-flex justify-content-between pr-3 pl-3" >
                                    <div>
                                        <h3>عنوان البرنامج </h3>
                                    </div>
                                    <div class="icon-show  d-flex"  >
                                        <i class="far fa-eye px-2" ></i>
                                        <i class="far fa-calendar-alt px-2"></i>
                                        <div class="input-show bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary"> 20 مشاهدة</a>
                                        </div>
                                        <div class="input-date bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary">12/16/2020</a>
                                        </div>
                                    </div>
                                </div>



                                <p class="entry-title mb-2 ">
                                    نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                    نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                    نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                </p>
                                <div class="col-auto  my-auto  d-flex justify-content-end more ">
                                    <button class=" btn-outline  mb-1 mb-md-0" >شاهد المزيد</button>
                                </div>
                            </div>

                        </article>
                    </div>
                </div>
                <div class="swiper-slide col-12  col-md-6  col-lg-4 p-4 h-100 ">
                    <div class="col-auto col-md-12  p-0 pb-2">

                        <article class="entry-box-1 mb-4 bg-primary shadow-sm h-100" >
                            <div class="new-box">
                                <div class="new  bg-primary text-white py-4  ">
                                    جديد
                                </div>
                                <a href="#" class="d-block">
                                    <img src="uploads/Ad1.jpg" class="img-fluid w-100" alt="اعلان.jpg">
                                </a>
                            </div>

                            <div class="entry-body p-3 pb-1">

                                <div class="row d-flex justify-content-between pr-3 pl-3" >
                                    <div>
                                        <h3>عنوان البرنامج </h3>
                                    </div>
                                    <div class="icon-show  d-flex"  >
                                        <i class="far fa-eye px-2" ></i>
                                        <i class="far fa-calendar-alt px-2"></i>
                                        <div class="input-show bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary"> 20 مشاهدة</a>
                                        </div>
                                        <div class="input-date bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary">12/16/2020</a>
                                        </div>
                                    </div>
                                </div>



                                <p class="entry-title mb-2 ">
                                    نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                    نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                    نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                </p>
                                <div class="col-auto  my-auto  d-flex justify-content-end more ">
                                    <button class=" btn-outline  mb-1 mb-md-0" >شاهد المزيد</button>
                                </div>
                            </div>

                        </article>
                    </div>
                </div>
                <div class="swiper-slide col-12  col-md-6  col-lg-4 p-4 h-100">
                    <div class="col-auto col-md-12 p-0 pb-2">

                        <article class="entry-box-1 mb-4 bg-primary shadow-sm h-100" >
                            <div class="new-box">
                                <div class="new  bg-primary text-white py-4  ">
                                    جديد
                                </div>
                                <a href="#" class="d-block">
                                    <img src="uploads/Ad1.jpg" class="img-fluid w-100" alt="اعلان.jpg">
                                </a>
                            </div>

                            <div class="entry-body p-3 pb-1">

                                <div class="row d-flex justify-content-between pr-3 pl-3" >
                                    <div>
                                        <h3>عنوان البرنامج </h3>
                                    </div>
                                    <div class="icon-show  d-flex"  >
                                        <i class="far fa-eye px-2" ></i>
                                        <i class="far fa-calendar-alt px-2"></i>
                                        <div class="input-show bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary"> 20 مشاهدة</a>
                                        </div>
                                        <div class="input-date bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary">12/16/2020</a>
                                        </div>
                                    </div>
                                </div>



                                <p class="entry-title mb-2 ">
                                    نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                    نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                    نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                </p>
                                <div class="col-auto  my-auto  d-flex justify-content-end more ">
                                    <button class=" btn-outline  mb-1 mb-md-0" >شاهد المزيد</button>
                                </div>
                            </div>

                        </article>
                    </div>
                </div>
            </div>
                <div class="swiper-button-next"><i class="fas fa-angle-left "></i></div>
                <div class="swiper-button-prev"><i class="fas fa-angle-right"></i></div>




    </div>






    
        </div>
</div>
            <div class="news  img-body-1  d-none d-md-block ">
                <img src="assets/images/bg-news.webp" alt="" class="img-fluid bg-img-fluid">

            </div>

            <div  class="block  lastnews">

            <div class="widget-1  ">
                <div class="container ">
                    <div class="row no-gutters ">


                        <div class="video-container   col-lg-8  col-12 col-md-12  mb-1 ">
                            <div class="video-play ">
                                <a class="video-play-link" data-player="video" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">


                                    <div class="work ">
                                        <div class="video-icon ">
                                            <div class="border-1"> </div>
                                            <img src="uploads/video.jpg" alt="" class="img-fluid">

                                            <div class="border border-success circle" >
                                                <span><i class="fas fa-play "></i> </span>
                                            </div>


                                        </div>
                                    </div>

                                </a>
                            </div>

                            <div class="video-player d-none">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                                </div>
                            </div>

                        </div>


                        <div class=" col-12 col-md-12 col-lg-4   ">

                            <div class="categories d-12 d-md-12 d-lg-block p-4   scroll  ">
                                <div class="title mb-2 ">
                                    <a href="#" class="d-flex">
                                        <i class="fas fa-bars fa-lg text-white "></i>
                                        <h3 class="video">قصص النجاح</h3>
                                    </a>
                                </div>

                                <div class=" " tabindex="5000" style="overflow: hidden; outline: none; ">

                                    <ul class="menu list-unstyled pt-2 px-0 ">
                                        <li class="menu-item   ">
                                            <div class="item  ">
                                                <a class="video-play-link" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">
                                                    <article class="entry-box-3 mb-0   bg-success  ">
                                                        <div class="row  mb-3">

                                                            <div class="col-3 p-0 col-md-3 col-lg-4">
                                                                <img src="uploads/video.jpg " class="img-fluid " style="width: 100% ;height: 100%" alt="">
                                                            </div>
                                                            <div class="entry-body mx-0  col-7 ">
                                                                <h5 class="entry-title pt-1 mb-0">عنوان الفيديو </h5>
                                                                <p class="entry-title pt-1 mb-2">هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة</p>

                                                            </div>
                                                        </div>
                                                    </article>
                                                </a>

                                            </div>

                                        </li>
                                        <li class="menu-item   ">
                                            <div class="item  ">
                                                <a class="video-play-link" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">
                                                    <article class="entry-box-3 mb-0   bg-success  ">
                                                        <div class="row  mb-3">

                                                            <div class="col-3 p-0 col-md-3 col-lg-4">
                                                                <img src="uploads/video.jpg " class="img-fluid " style="width: 100% ;height: 100%" alt="">
                                                            </div>
                                                            <div class="entry-body mx-0  col-7 ">
                                                                <h5 class="entry-title pt-1 mb-0">عنوان الفيديو </h5>
                                                                <p class="entry-title pt-1 mb-2">هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة</p>

                                                            </div>
                                                        </div>
                                                    </article>
                                                </a>

                                            </div>

                                        </li>
                                        <li class="menu-item   ">
                                            <div class="item  ">
                                                <a class="video-play-link" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">
                                                    <article class="entry-box-3 mb-0   bg-success  ">
                                                        <div class="row  mb-3">

                                                            <div class="col-3 p-0 col-md-3 col-lg-4">
                                                                <img src="uploads/video.jpg " class="img-fluid " style="width: 100% ;height: 100%" alt="">
                                                            </div>
                                                            <div class="entry-body mx-0  col-7 ">
                                                                <h5 class="entry-title pt-1 mb-0">عنوان الفيديو </h5>
                                                                <p class="entry-title pt-1 mb-2">هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة</p>

                                                            </div>
                                                        </div>
                                                    </article>
                                                </a>

                                            </div>

                                        </li>
                                        <li class="menu-item   ">
                                            <div class="item  ">
                                                <a class="video-play-link" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">
                                                    <article class="entry-box-3 mb-0   bg-success  ">
                                                        <div class="row  mb-3">

                                                            <div class="col-3 p-0 col-md-3 col-lg-4">
                                                                <img src="uploads/video.jpg " class="img-fluid " style="width: 100% ;height: 100%" alt="">
                                                            </div>
                                                            <div class="entry-body mx-0  col-7 ">
                                                                <h5 class="entry-title pt-1 mb-0">عنوان الفيديو </h5>
                                                                <p class="entry-title pt-1 mb-2">هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة</p>

                                                            </div>
                                                        </div>
                                                    </article>
                                                </a>

                                            </div>

                                        </li>
                                        <li class="menu-item   ">
                                            <div class="item  ">
                                                <a class="video-play-link" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">
                                                    <article class="entry-box-3 mb-0   bg-success  ">
                                                        <div class="row  mb-3">

                                                            <div class="col-3 p-0 col-md-3 col-lg-4">
                                                                <img src="uploads/video.jpg " class="img-fluid " style="width: 100% ;height: 100%" alt="">
                                                            </div>
                                                            <div class="entry-body mx-0  col-7 ">
                                                                <h5 class="entry-title pt-1 mb-0">عنوان الفيديو </h5>
                                                                <p class="entry-title pt-1 mb-2">هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة</p>

                                                            </div>
                                                        </div>
                                                    </article>
                                                </a>

                                            </div>

                                        </li>
                                        <li class="menu-item   ">
                                            <div class="item  ">
                                                <a class="video-play-link" href="https://www.dailymotion.com/embed/video/x7os203?autoPlay=1">
                                                    <article class="entry-box-3 mb-0   bg-success  ">
                                                        <div class="row  mb-3">

                                                            <div class="col-3 p-0 col-md-3 col-lg-4">
                                                                <img src="uploads/video.jpg " class="img-fluid " style="width: 100% ;height: 100%" alt="">
                                                            </div>
                                                            <div class="entry-body mx-0  col-7 ">
                                                                <h5 class="entry-title pt-1 mb-0">عنوان الفيديو </h5>
                                                                <p class="entry-title pt-1 mb-2">هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة</p>

                                                            </div>
                                                        </div>
                                                    </article>
                                                </a>

                                            </div>

                                        </li>
                                    </ul>



                                </div>
                                <div class="icon-scroll">
                                    <i class="fas fa-angle-down"></i>
                                    <i class="fas fa-angle-up"></i>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            </div>
                <div class=" news img-body-2  d-none d-md-block ">
                    <img src="assets/images/bg-news.webp" alt="" class="img-fluid bg-img-fluid">

                </div>


