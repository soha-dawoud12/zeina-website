<div id="ourpartners" class="block ourpartners  mb-4" >
    <div class="container">


        <div class="head-start  text-center mb-5">
            <h2 class="line-home">شركاؤنا</h2>

        </div>
        <div class="swiper-container ">
            <div class="swiper-wrapper text-center p-3">
                <div class="swiper-slide ">
                    <picture><img src="uploads/Cocacola-logo.png" alt="" class="img-fluid w-100 " > </picture>
                </div>
                <div class="swiper-slide ">
                    <picture><img src="uploads/Cocacola-logo.png" alt="" class="img-fluid w-100 " > </picture>
                </div>
                <div class="swiper-slide">
                    <picture><img src="uploads/google_logo-1024x628.png" alt="" class="img-fluid w-100" > </picture>
                </div>
                <div class="swiper-slide">
                    <picture><img src="uploads/Mask%20Group%209.png" alt="" class="img-fluid w-100" > </picture>
                </div>
                <div class="swiper-slide">
                    <div class="swiper-slide ">
                        <picture><img src="uploads/أودي.png" alt="" class="img-fluid w-100" > </picture>
                    </div></div>
                <div class="swiper-slide">
                    <div class="swiper-slide ">
                        <picture><img src="uploads/شعار-بيبسي.png" alt="" class="img-fluid w-100" > </picture>
                    </div></div>
                <div class="swiper-slide">
                    <div class="swiper-slide ">
                        <picture><img src="uploads/شعارات-الصوالين.png" alt="" class="img-fluid w-100" > </picture>
                    </div></div>
                <div class="swiper-slide">
                    <div class="swiper-slide ">
                        <picture><img src="uploads/شعار-بيبسي.png" alt="" class="img-fluid w-100" > </picture>
                    </div></div>

            </div>







            <div class="swiper-pagination mt-4 d-flex justify-content-center  swiper-pagination-clickable"></div>



        </div>
        <div class=" img-body-2 d-none d-md-block " >
            <img src="assets/images/Group%208813.webp" alt="" class="img-fluid bg-img-fluid">
        </div>
        <div id="whyzeina" class="  whyzeina mt-5 pt-5" >
            <div class="container">


                <div class="head-start  text-center mb-5">
                    <h2>لماذا زينة</h2>

                </div>
                <div class="row m-auto text-center">
                    <div class="col-12 col-md-4 mb-2">
                        <picture>
                            <img src="assets/images/community.png" alt="" class="img-fluid mb-2">
                        </picture>
                        <p class="font-weight-bold">
                            نهتم بتنمية وتطوير المجتمع
                        </p>
                    </div>
                    <div class="col-12 col-md-4 mb-2">
                        <picture>
                            <img src="assets/images/chat%20(1).png" alt="" class="img-fluid mb-2">
                        </picture>
                        <p class="font-weight-bold">
                            ندعم التعاون، الديمقراطية والشفافية في العمل
                        </p>
                    </div>
                    <div class="col-12 col-md-4 mb-2">
                        <picture>
                            <img src="assets/images/first.png" alt="" class="img-fluid mb-2">
                        </picture>
                        <p class="font-weight-bold">
                            الجمعية العمالية الأولى في فلسطين
                        </p>
                    </div>

                </div>


            </div>
        </div>
    </div>
</div>