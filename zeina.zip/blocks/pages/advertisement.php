<div id="advertisement" class="block  btn-special advertisement" >
    <div class="container">


        <div class="head-start  text-center mb-5">
            <h2 class="line-home"> الاعلانات</h2>

        </div>
        <div class="row m-auto ">
            <div class="col-auto col-md-4 pb-2">

                    <article class="entry-box-1 mb-4 bg-primary shadow-sm h-100" >
                       <div class="new-box">
                           <div class="new  bg-success text-white py-4  font-weight-bold  ">
                            جديد
                           </div>
                           <a href="#" class="d-block">
                               <img src="uploads/Ad1.jpg" class="img-fluid w-100" alt="اعلان.jpg">
                           </a>
                       </div>

                            <div class="entry-body p-3 pb-1">

                                <div class="row d-flex justify-content-between pr-3 pl-3" >
                                  <div>
                                      <h3>عنوان البرنامج </h3>
                                  </div>
                                    <div class="icon-show  d-flex"  >
                                        <i class="far fa-eye px-2" ></i>
                                        <i class="far fa-calendar-alt px-2"></i>
                                        <div class="input-show bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary"> 20 مشاهدة</a>
                                        </div>
                                        <div class="input-date bg-white p-1" style="border: 1px solid var(--success)" >
                                            <a href="" class="text-primary">12/16/2020</a>
                                        </div>
                                    </div>

                                </div>



                                <p class="entry-title mb-2 ">
                                    نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                    نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                    نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                </p>
                                <div class="col-auto  my-auto  d-flex justify-content-end more ">
                                    <button class=" btn-outline  mb-1 mb-md-0" >شاهد المزيد</button>
                                </div>
                            </div>

                    </article>
                </div>
            <div class="col-auto col-md-4 pb-2">

                <article class="entry-box-1 mb-4 bg-primary shadow-sm h-100" >
                    <div class="new-box">
                        <div class="new  bg-success text-white py-4  font-weight-bold  ">
                            جديد
                        </div>
                        <a href="#" class="d-block">
                            <img src="uploads/Ad1.jpg" class="img-fluid w-100" alt="اعلان.jpg">
                        </a>
                    </div>

                    <div class="entry-body p-3 pb-1">

                        <div class="row d-flex justify-content-between pr-3 pl-3" >
                            <div>
                                <h3>عنوان البرنامج </h3>
                            </div>
                            <div class="icon-show  d-flex"  >
                                <i class="far fa-eye px-2" ></i>
                                <i class="far fa-calendar-alt px-2"></i>
                                <div class="input-show bg-white p-1" style="border: 1px solid var(--success)" >
                                    <a href="" class="text-primary"> 20 مشاهدة</a>
                                </div>
                                <div class="input-date bg-white p-1" style="border: 1px solid var(--success)" >
                                    <a href="" class="text-primary">12/16/2020</a>
                                </div>
                            </div>

                        </div>



                        <p class="entry-title mb-2 ">
                            نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                            نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                            نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                        </p>
                        <div class="col-auto  my-auto  d-flex justify-content-end more ">
                            <button class=" btn-outline  mb-1 mb-md-0" >شاهد المزيد</button>
                        </div>
                    </div>

                </article>
            </div>
            <div class="col-auto col-md-4 pb-2">

                <article class="entry-box-1 mb-4 bg-primary shadow-sm h-100" >
                    <div class="new-box">
                        <div class="new  bg-success text-white py-4  font-weight-bold  ">
                            جديد
                        </div>
                        <a href="#" class="d-block">
                            <img src="uploads/Ad1.jpg" class="img-fluid w-100" alt="اعلان.jpg">
                        </a>
                    </div>

                    <div class="entry-body p-3 pb-1">

                        <div class="row d-flex justify-content-between pr-3 pl-3" >
                            <div>
                                <h3>عنوان البرنامج </h3>
                            </div>
                            <div class="icon-show  d-flex"  >
                                <i class="far fa-eye px-2" ></i>
                                <i class="far fa-calendar-alt px-2"></i>
                                <div class="input-show bg-white p-1" style="border: 1px solid var(--success)" >
                                    <a href="" class="text-primary"> 20 مشاهدة</a>
                                </div>
                                <div class="input-date bg-white p-1" style="border: 1px solid var(--success)" >
                                    <a href="" class="text-primary">12/16/2020</a>
                                </div>
                            </div>

                        </div>



                        <p class="entry-title mb-2 ">
                            نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                            نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                            نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                        </p>
                        <div class="col-auto  my-auto  d-flex justify-content-end more ">
                            <button class=" btn-outline  mb-1 mb-md-0" >شاهد المزيد</button>
                        </div>
                    </div>

                </article>
            </div>
            </div>


        </div>


    </div>
</div>