<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>شاهد المزيد</title>
    <?php include 'blocks/layouts/head-resources.php' ?>
</head>

<body class="header-fixed">
<?php include 'social.php' ?>

<div class="loader">
    <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>

</div>
            <?php include 'blocks/layouts/header.php'?>
            <?php include 'blocks/pages/mobile-menu.php'?>

            <div id="why-zeina" class="block  see-more  h-100 mt-xl-4 wow bounceInDown " data-wow-duration="2s" data-wow-delay="50ms">
                <div class="container">
                    <div class="row d-flex align-items-center justify-content-center">


                    <div class="col-12 col-md-5 img-see-more mb-2">
                        <img src="uploads/Ad1.jpg" alt="">
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="entry-body p-1 pb-1">

                            <h4 class="font-weight-bold ">اسم الشخص </h4>
                            <h6 class="">اللقب</h6>

                            <p class="entry-title mb-2 ">
                                نص افتراضي نص افتراضي نص افتراضي نصننصنصص
                                نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                                نةكمكم نص افتراضي نص افتراضي نص افتراضي نصنصنصنص
                            </p>
                        </div>
                    </div>
                    </div>
                </div>

                </div>




            <?php include 'blocks/layouts/footer.php'?>

            <?php include 'blocks/layouts/foot-resources.php' ?>
</body>
</html>